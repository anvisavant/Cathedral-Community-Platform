from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.core.validators import MaxValueValidator, MinValueValidator


# written by arnav

class Student(models.Model):
    Student_user = models.OneToOneField(User, on_delete = models.CASCADE)
    Student_email_backup = models.CharField(max_length = 100)
    Student_grade = models.IntegerField()
    Student_division = models.CharField(max_length = 10)
    Student_board = models.CharField(max_length = 30)

    # returns the name of the student
    def __str__(self):
        name = ""
        if(self.user.first_name != ""):
            name = self.user.first_name + " " + self.user.last_name
        else:
            name = self.user.username
        return(name)
    #checkes if it is the same student as the self student
    def EqualsUser(self, student):
        return (self.Student_user.id == student.Student_user.id)

    #check if the entire entry in the database is the same
    def Equals(self, student):
        return self.id == student.id


# written by arnav
class Alumni(models.Model):
    Alumni_user = models.OneToOneField(User, on_delete = models.CASCADE)
    #Alumni_mail_2 = models.CharField(max_length = 100) CAN WE DELETE THIS?
    Alumni_college = models.CharField(max_length = 50, blank = True) # the blank statement allows the user to leave the field empty in a form
    Alumni_field = models.CharField(max_length = 50, blank = True)
    Alumni_year_of_graduation = models.IntegerField() # this stores the year of graduation from school
    Alumni_job_description = models.CharField(max_length = 2000, blank = True) #job description

    # returns the name of the student
    def __str__(self):
        name = ""
        if(self.user.first_name != ""):
            name = self.user.first_name + " " + self.user.last_name
        else:
            name = self.user.username
        return(name)

    #checkes if it is the same student as the self student
    def EqualsUser(self, alum):
        return (self.Student_user.id == alum.Student_user.id)
    #check if the entire entry in the database is the same
    def Equals(self, alum):
        return self.id == alum.id

# written by Dev D approved by arnav
class Teacher(models.Model):
    Teacher_user = models.OneToOneField(User, on_delete=models.CASCADE)
    #email_2 = models.CharField(max_length = 100) CAN WE DELETE THIS?
    Teacher_sub1 = models.CharField(max_length=50, null = True)
    Teacher_sub2 = models.CharField(max_length=50, blank = True)
    Teacher_sub3 = models.CharField(max_length=50, blank = True)

    # returns the name of the student
    def __str__(self):
        name = ""
        if(self.user.first_name != ""):
            name = self.user.first_name + " " + self.user.last_name
        else:
            name = self.user.username
        return(name)

    #checkes if it is the same student as the self student
    def EqualsUser(self, teacher):
        return (self.Student_user.id == teacher.Student_user.id)
    #check if the entire entry in the database is the same
    def Equals(self, teacher):
        return (self.id == teacher.id)


# written by Dev D approved by arnav
class Project(models.Model):
    Project_creator_user = models.ManyToManyField(Student)
    Project_tag1 = models.CharField(max_length=50)
    Project_tag2 = models.CharField(max_length=50, null = True)
    Project_tag3 = models.CharField(max_length=50, null = True)
    Project_tag4 = models.CharField(max_length=50, null = True)
    Project_description = models.CharField(max_length=750, blank = True)
    Project_creator_grade = models.IntegerField(validators=[MaxValueValidator(12), MinValueValidator(8)])
    Project_name= models.CharField(max_length=100)

    # returns the name of the project
    def __str__(self):
        Pname = self.Project_name
        return Pname


    # returns the tags
    def GetTags(self):
        tagArray = [];
        tagArray.append(Project_tag1)
        tagArray.append(Project_tag2)
        tagArray.append(Project_tag3)
        tagArray.append(Project_tag4)
        return tagArray





# to store all the tags in one place
class Tags(models.Model):
    Tags = models.CharField(max_length=100)

class UserTags(models.Model):
    Tags_user = models.ForeignKey(User, on_delete=models.CASCADE)
    project_participant= models.ForeignKey(Tags, on_delete=models.CASCADE)

    # given a user if the user matches then it returns the tag associated with the user
    # checks if the user matches
    def UserMatch(self, user):
        return(user.id == Tags_user.id)
    # prints the tag name
    def __str__(self):
        return Tags



class project_participants(models.Model):
    project_name = models.ForeignKey(Project, on_delete=models.CASCADE)
    project_participant= models.ForeignKey(User, on_delete=models.CASCADE)

class test(models.Model):
    name = models.CharField(max_length=100)
