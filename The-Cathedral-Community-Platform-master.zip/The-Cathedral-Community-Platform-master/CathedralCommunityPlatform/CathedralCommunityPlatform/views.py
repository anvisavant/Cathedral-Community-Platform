from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import Context, loader
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout

from .models import *
from .Utils import *

#Method written and approved by Aryaman Kejriwal
def format(request):
    context = {'Title':'Format'}
    return(render(request, 'format.html', context))

#Method written and approved by Aryaman Kejriwal
def home(request):
    context = {'Title':'Home'}
    return(render(request, 'home.html', context))


#Method written by Himnish Jain, approved by Aryaman Kejriwal
def login(request):
    context = {"Title": "Login"}
    return(render(request, "login.html", context))


#Method written by Himnish Jain, approved by Aryaman Kejriwal
def announcements(request):
    context = {"Title": "Announcements"}
    #Template Pending
    return(render(request, "announcements.html", context))


#Method written by Himnish Jain, approved by Aryaman Kejriwal
def tags(request):
    context = {"Title": "Tags"}
    #Template Pending
    return(render(request, "tags.html", context))


#Method written by Himnish Jain, approved by Aryaman Kejriwal
def projects(request):
    context = {"Title": "Projects"}
    #Template Pending
    return(render(request, "projects.html", context))

#Method written and approved by Aryaman Kejriwal
def internships(request):
    context = {"Title": "Internships"}
    return(render(request, "internships.html", context))

#Method written by Himnish Jain, approved by Aryaman Kejriwal
def alumni(request):
    context = {"Title": "Alumni"}
    #Template Pending
    return(render(request, "alumni.html", context))

#Method written and approved by Aryaman Kejriwal
def faculty(request):
    context = {"Title": "Faculty"}
    return(render(request, "faculty.html", context))

#Method written by Himnish Jain, approved by Aryaman Kejriwal
def students(request):
    context = {"Title": "Students"}
    #Template Pending
    return(render(request, "students.html", context))


#Method written by Himnish Jain, approved by Aryaman Kejriwal
def chat(request):
    context = {"Title": "Chat"}
    #Template Pending
    return(render(request, "chat.html", context))


#Method written by Alekha Malhotra, approved by Aryaman Kejriwal
@login_required(login_url='/login/')
def profile(request):
    context = {'Title': 'Profile'}
    #Template Pending
    return(render(request, 'profile.html',context))

#Method written by Alekha Malhotra, approved by Aryaman Kejriwal
def teachersemails(request):
    context = {'Title': 'Faculty'}
    #Template Pending
    return(render(request, 'faculty.html',context))
