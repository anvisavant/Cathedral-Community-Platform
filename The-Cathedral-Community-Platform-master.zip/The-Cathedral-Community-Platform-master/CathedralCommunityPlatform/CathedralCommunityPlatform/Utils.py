from .models import *
class Utils:

    def AddStudent(user, email_back, grade, division, board):
        student = Student.objects.create()
        student.Student_user = user
        student.Student_email_backup = email_back
        student.Student_grade = grade
        student.Student_division = division
        student.Student_board = board
        student.save() # saves to the database
        return student

    def AddTeacher(user, sub1, sub2, sub3):
        teacher = Teacher.objects.create()
        teacher.Teacher_user = user
        teacher.Teacher_sub1 = sub1
        teacher.Teacher_sub2 = sub2
        teacher.Teacher_sub3 = sub3
        teacher.save() # saves teacher to db
        return teacher

    def AddAlumni(user, yog, field= None, college = None, Jobdesc = None):
        alum = Alumni.objects.create()
        alum.Alumni_user = user
        alum.Alumni_year_of_graduation = yog
        alum.Alumni_field = field
        alum.Alumni_college = college
        alum.Alumni_job_description = Jobdesc
        alum.save()
        return alum
